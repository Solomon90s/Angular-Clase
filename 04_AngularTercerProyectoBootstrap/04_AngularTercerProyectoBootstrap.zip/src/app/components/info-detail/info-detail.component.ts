import {Component, OnInit} from '@angular/core';
import {ActivatedRoute} from "@angular/router";
import {CharacterRM} from "../../common/interfaces";
import {RickymortyService} from "../../services/rickymorty.service";

@Component({
  selector: 'app-info-detail',
  templateUrl: './info-detail.component.html',
  styleUrls: ['./info-detail.component.css']
})
export class InfoDetailComponent implements OnInit {

  // Creamos una variable del id del personaje
  idChar: number = 0;

  // Recogemos el personaje
  char!: CharacterRM;

  // Recogemos el valor
  constructor(private activatedRoute: ActivatedRoute,
              private dataService: RickymortyService) {
    // Nos permite acceder a las variables de la ruta
  }
  ngOnInit(): void {
    this.loadChar();
  }

  private loadChar() {
    // el id del personaje lo podemos recoger de 2 maneras, dinamica (va a variar) y estatica (no va a variar)

    // Esta es la manera estática, solo voy a usar el parametro una única vez
    // this.idChar = this.activatedRoute.snapshot.params['id'];
    // console.log(this.activatedRoute.snapshot.params);

    // Esta es la manera dinámica
    this.activatedRoute.params.subscribe({
      next: value => {
        this.idChar = value['id'];
        this.dataService.getCharacter(this.idChar).subscribe({
          next: charData => {
            this.char = charData;
            console.log(this.char);
          },
          error: err => {
            console.log(err);
          },
          complete: () => {
            console.log('Char loaded');
          }
        })
      },
      error: err => {
        console.log(err);
      },
      complete: () => {
        console.log('Done');
      }
    });
  }
}
